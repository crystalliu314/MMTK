import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.awt.Frame; 
import java.awt.BorderLayout; 
import controlP5.*; 
import processing.serial.*; 
import java.util.Arrays; 
import java.util.Random; 
import java.util.concurrent.ThreadLocalRandom; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class MMTK_UI extends PApplet {

/**
 * MMTK UI
 *
 * Simple UI sketch to plot the output data and show state of buttons and stuff
 *
 * Requires:
 * - ControlP5 library (install from processing)
 * 
 * This is based on Real Time Plotter Library from https://github.com/sebnil/RealtimePlotter
 */
 
// import libraries


 // http://www.sojamo.de/libraries/controlP5/



// If you want to debug the plotter without using a real serial port set this to true
boolean mockupSerial = true;

// Serial Setup
String serialPortName;
Serial serialPort;  // Create object from Serial class

// interface stuff
ControlP5 cp5;

// Settings for the plotter are saved in this file
JSONObject plotterConfigJSON;

// ***********************
// ** Drawing Constants **
// ***********************
int[] screenSize = {1080, 720};

int[] XYplotOrigin = {100, 170};
int[] XYplotSize = {400, 300};
int XYplotColor = color(20, 20, 200);

int[] eStopIndicatorOrigin = {500, 600};
int[] eStopIndicatorSize = {50,50};
int eStopActiveColor = color(250,0,0);
int eStopInactiveColor = color(0,250,0);

int buttonActiveColor = color(120,255,120);
int buttonInactiveColor = color(255,120,120);
int buttonBorderColor = 10;
int[] buttonIndicatorSize = {50,50};

int [] buttonForwardOrigin = {600,600};
int [] buttonBackOrigin = {700,600};
int [] buttonTareOrigin = {800,600};
int [] buttonStartOrigin = {900,600};
int [] buttonAuxOrigin = {1000,600};

// Generate the plot
int[] XYplotFloatDataDims = {4, 10000};
int[] XYplotIntDataDims = {5, 10000};

Graph XYplot = new Graph(XYplotOrigin[0], XYplotOrigin[1], XYplotSize[0], XYplotSize[1], XYplotColor);
float[][] XYplotFloatData = new float[XYplotFloatDataDims[0]][XYplotFloatDataDims[1]];
int[][] XYplotIntData = new int[XYplotIntDataDims[0]][XYplotIntDataDims[1]];
// This value grows and is used for slicing
int XYplotCurrentSize = 0;


// ************************
// ** Variables for Data **
// ************************


float speed = 0.0f;
float position = 0.0f;
float loadCell = 0.0f;
int feedBack = 0;
int MMTKState = 0;
int eStop = 0;
int stall = 0;
int direction = 0;
float inputVolts = 12.0f;

int btBak = 0;
int btFwd = 0;
int btTare = 0;
int btStart = 0;
int btAux = 0;


// helper for saving the executing path
String topSketchPath = "";

// Log File
PrintWriter logFile;

// MMTK logo image
PImage mmtkLogo;


public void settings() {
    size(screenSize[0], screenSize[1]);
}

public void setup() 
{
  // Create a new file in the sketch directory
  String logFileName = "logs/MMTK" 
                       +" " + String.format("%04d", year()) 
                       + "-" + String.format("%02d", month()) 
                       + "-" + String.format("%02d", day()) 
                       + " " + String.format("%02d", hour()) 
                       + "-" + String.format("%02d", minute()) 
                       + "-" + String.format("%02d", second()) 
                       + ".txt";
  try {
   logFile = createWriter(logFileName); 
  }
  catch (Exception e) {
    System.out.println(e);
  }
  
  logFile.println("Started Log File:     " + logFileName);
  logFile.flush(); // Writes the remaining data to the file
  
  // settings save file
  topSketchPath = sketchPath();
  plotterConfigJSON = loadJSONObject(topSketchPath+"/plotter_config.json");
  
  surface.setTitle("Realtime plotter");
  
  // settings save file
  topSketchPath = sketchPath();
  plotterConfigJSON = loadJSONObject(topSketchPath+"/plotter_config.json");

  // gui
  cp5 = new ControlP5(this);
  
  // init charts
  setChartSettings();
  
  
  // start serial communication
  //serialPortName = Serial.list()[0];
  if (!mockupSerial) {
    //String serialPortName = Serial.list()[3];
    serialPort = new Serial(this, serialPortName, 115200);
  }
  else
    serialPort = null;

  
  // Draw MMTK Logo image
  mmtkLogo = loadImage("/images/mmtk-logo.png");

}








// *******************************
// ** MAIN DRAW LOOP START HERE **
// *******************************


byte[] inBuffer = new byte[1000]; // holds serial message
int i = 0; // loop variable
int j = 0;

public void draw()
{  
  
  setChartSettings();
  /* Read serial and update values */
  if (mockupSerial || serialPort.available() > 0) {
    String myString = "";
    if (!mockupSerial) {
      try {
        serialPort.readBytesUntil('\r', inBuffer);
      }
      catch (Exception e) {
      }
      myString = new String(inBuffer);
    }
    else {
      myString = mockupSerialFunction();
    }

    // Print out the data for debugging and logging
    System.out.println(myString);
    logFile.println(myString);
    
    
    if (myString.contains("TARE")) {
      // This is a tare frame, empty the array and ignore it
      // Also ignore the next line with indices
      serialPort.readBytesUntil('\r', inBuffer);
      XYplotCurrentSize = 0;
      
    } else {
      // split the string at delimiter (space)
      String[] tempData = split(myString, ' ');   

      // build the arrays for bar charts and line graphs
      if (tempData.length == 15) {
        // This is a normal data frame
        // SPEED POSITION LOADCELL FEEDBACK_COUNT STATE ESTOP STALL DIRECTION INPUT_VOLTAGE BT_FWD BT_BAK BT_TARE BT_START BT_AUX and a space
        
        try {
          speed = Float.parseFloat(trim(tempData[0]));
          position = Float.parseFloat(trim(tempData[1]));
          loadCell = Float.parseFloat(trim(tempData[2]));
          feedBack = Integer.parseInt(trim(tempData[3]));
          MMTKState = Integer.parseInt(trim(tempData[4]));
          eStop = Integer.parseInt(trim(tempData[5]));
          stall = Integer.parseInt(trim(tempData[6]));
          direction = Integer.parseInt(trim(tempData[7]));
          inputVolts = Float.parseFloat(trim(tempData[8]));
          
          btBak = Integer.parseInt(trim(tempData[9]));
          btFwd = Integer.parseInt(trim(tempData[10]));
          btTare = Integer.parseInt(trim(tempData[11]));
          btStart = Integer.parseInt(trim(tempData[12]));
          btAux = Integer.parseInt(trim(tempData[13]));
        }
        catch (NumberFormatException e) {
          System.out.println(e);
        }
        
      } else {
        // invalid message ignore it
        System.out.println("Corrupted Serial Message Frame Ignored");
      }
      
      // If the current data is longer than our buffer
      // Have to expand the buffer and continue
      if (XYplotCurrentSize >= XYplotIntData[0].length) {
        System.out.println("=========== expand buffer ==============");
        int newLength = XYplotIntDataDims[1] + XYplotIntData[0].length;
        int[][] tempIntData = new int[XYplotIntDataDims[0]][newLength];
        float[][] tempFloatData = new float[XYplotFloatDataDims[0]][newLength];

        // Copy data to this bigger array
        for (i=0; i<tempIntData.length; i++) {
          System.arraycopy(XYplotIntData[i], 0, tempIntData[i], 0, XYplotIntData[i].length);    
        }
        for (i=0; i<XYplotFloatData.length; i++) {
          System.arraycopy(XYplotFloatData[i], 0, tempFloatData[i], 0, XYplotFloatData[i].length);    
        }
        XYplotIntData = tempIntData;
        XYplotFloatData = tempFloatData;
      }
    
      // update the data buffer        
        
        
        XYplotFloatData[0][XYplotCurrentSize] = speed;
        XYplotFloatData[1][XYplotCurrentSize] = position;
        XYplotFloatData[2][XYplotCurrentSize] = loadCell;
        XYplotFloatData[3][XYplotCurrentSize] = inputVolts;
        
        XYplotIntData[0][XYplotCurrentSize] = feedBack;
        XYplotIntData[1][XYplotCurrentSize] = MMTKState;
        XYplotIntData[2][XYplotCurrentSize] = eStop;
        XYplotIntData[3][XYplotCurrentSize] = stall;
        XYplotIntData[4][XYplotCurrentSize] = direction;
        
        XYplotCurrentSize ++;
        
    }
      
      
    
    }

    
    
  
  // draw the bar chart
  background(200); 
  
  
  // Draw the MMTK Logo
  image(mmtkLogo, 0, 0, 300, 100);

  // Copy data to plot into new array for plotting
  float[] plotDisplacement = Arrays.copyOfRange(XYplotFloatData[1], 0, XYplotCurrentSize);
  float[] plotForce = Arrays.copyOfRange(XYplotFloatData[2], 0, XYplotCurrentSize);
  

  // draw the line graphs
  XYplot.DrawAxis();
  XYplot.GraphColor = XYplotColor;
  XYplot.DotXY(plotDisplacement, plotForce);
  
  
  
  // Draw / update buttons
  
  // Buttons
  stroke(buttonBorderColor);
  fill(buttonActiveColor);
  
  
//int buttonActiveColor = color(120,255,120);
//int buttonInactiveColor = color(255,120,120);
//int[] buttonIndicatorSize = {50,50};
  if (btFwd >= 1) {
    fill(buttonActiveColor);
  } else {
    fill(buttonInactiveColor);
  }
  rect(buttonForwardOrigin[0], buttonForwardOrigin[1], buttonIndicatorSize[0], buttonIndicatorSize[1]);
  
  if (btBak >= 1) {
    fill(buttonActiveColor);
  } else {
    fill(buttonInactiveColor);
  }
  rect(buttonBackOrigin[0], buttonBackOrigin[1],  buttonIndicatorSize[0], buttonIndicatorSize[1]);
  
  if (btTare >= 1) {
    fill(buttonActiveColor);
  } else {
    fill(buttonInactiveColor);
  }
  rect(buttonTareOrigin[0], buttonTareOrigin[1], buttonIndicatorSize[0], buttonIndicatorSize[1]);
  
  if (btStart >= 1) {
    fill(buttonActiveColor);
  } else {
    fill(buttonInactiveColor);
  }
  rect(buttonStartOrigin[0], buttonStartOrigin[1], buttonIndicatorSize[0], buttonIndicatorSize[1]);
  
  if (btAux >= 1) {
    fill(buttonActiveColor);
  } else {
    fill(buttonInactiveColor);
  }
  rect(buttonAuxOrigin[0], buttonAuxOrigin[1], buttonIndicatorSize[0], buttonIndicatorSize[1]);
}
















// *********************
// ** HELPER FUNCTIONS **
// **********************


// called each time the chart settings are changed by the user 
public void setChartSettings() {
  XYplot.xLabel=" Displacment (mm) ";
  XYplot.yLabel=" Force (N) ";
  XYplot.Title="";  
  XYplot.xDiv=2;  
  XYplot.xMax=1000; 
  XYplot.xMin=-10;  
  XYplot.yMax=1000; 
  XYplot.yMin=-10;
}

// handle gui actions
public void controlEvent(ControlEvent theEvent) {
  if (theEvent.isAssignableFrom(Textfield.class) || theEvent.isAssignableFrom(Toggle.class) || theEvent.isAssignableFrom(Button.class)) {
    String parameter = theEvent.getName();
    String value = "";
    if (theEvent.isAssignableFrom(Textfield.class))
      value = theEvent.getStringValue();
    else if (theEvent.isAssignableFrom(Toggle.class) || theEvent.isAssignableFrom(Button.class))
      value = theEvent.getValue()+"";

    plotterConfigJSON.setString(parameter, value);
    saveJSONObject(plotterConfigJSON, topSketchPath+"/plotter_config.json");
  }
  setChartSettings();
}

// get gui settings from settings file
public String getPlotterConfigString(String id) {
  String r = "";
  try {
    r = plotterConfigJSON.getString(id);
  } 
  catch (Exception e) {
    r = "";
  }
  return r;
}
// Settings for the control panel are saved in this file
JSONObject robotConfigJSON;

// the ControlFrame class extends PApplet, so we 
// are creating a new processing applet inside a
// new frame with a controlP5 object loaded
public class ControlFrame extends PApplet {

  int w, h;

  int abc = 100;

  public void settings() {
    size(w, h);
    
  }

  public void setup() {
    surface.setLocation(100, 100);
    surface.setResizable(false);
    surface.setVisible(true);
    frameRate(25);
    cp5 = new ControlP5(this);

    robotConfigJSON = loadJSONObject(topSketchPath+"/robot_config.json");
    //printArray(json.getJSONObject("sensors2").getJSONObject("1"));

    // speed PID
    int x;
    int y;
    cp5.addTextlabel("label").setText("Speed PID (outer loop)").setPosition(x=5, y=5).setFont(createFont("Georgia", 12));
    cp5.addTextfield("speed-PID Kp").setPosition(x=x+5, y=y+20).setText(getConfigString("speedPIDKp")).setWidth(40).setAutoClear(false);
    cp5.addTextfield("speed-PID Ki").setPosition(x, y=y+40).setText(getConfigString("speedPIDKi")).setWidth(40).setAutoClear(false);
    cp5.addTextfield("speed-PID Kd").setPosition(x, y=y+40).setText(getConfigString("speedPIDKd")).setWidth(40).setAutoClear(false);
    cp5.addTextfield("speed-PID Output LowerLimit").setPosition(x, y=y+60).setText(getConfigString("speedPIDOutputLowerLimit")).setWidth(40).setAutoClear(false);
    cp5.addTextfield("speed-PID Output HigherLimit").setPosition(x, y=y+40).setText(getConfigString("speedPIDOutputHigherLimit")).setWidth(40).setAutoClear(false);
    cp5.addTextfield("speed-PID Sampling").setPosition(x, y=y+40).setText(getConfigString("speedPIDSampling")).setWidth(40).setAutoClear(false);
    cp5.addTextfield("motor Speed SensorSampling").setPosition(x, y=y+40).setText(getConfigString("motorSpeedSensorSampling")).setWidth(40).setAutoClear(false);
    cp5.addTextfield("speed Kalman FilterR").setPosition(x, y=y+40).setText(getConfigString("speedKalmanFilterR")).setWidth(40).setAutoClear(false);

    // angple PID
    x = x+150;
    y = 5;
    cp5.addTextlabel("Angle PID (outer loop)").setText("Angle PID (outer loop)").setPosition(x, y).setFont(createFont("Georgia", 12));
    x = x + 5;
    y = y+20;
    cp5.addTextlabel("Conservative").setText("Conservative").setPosition(x, y).setFont(createFont("Georgia", 12));
    x = x + 100;
    cp5.addTextlabel("Aggressive").setText("Aggressive").setPosition(x, y).setFont(createFont("Georgia", 12));
    x = x - 95;
    y = y+20;
    cp5.addTextfield("angle-PID ConKp").setPosition(x, y).setText(getConfigString("anglePIDConKp")).setWidth(40).setAutoClear(false);
    x = x + 100;
    cp5.addTextfield("angle-PID AggKp").setPosition(x, y).setText(getConfigString("anglePIDAggKp")).setWidth(40).setAutoClear(false);
    x = x - 100;
    y = y+40;
    cp5.addTextfield("angle-PID ConKi").setPosition(x, y).setText(getConfigString("anglePIDConKi")).setWidth(40).setAutoClear(false);
    x = x + 100;
    cp5.addTextfield("anglePIDAggKi").setPosition(x, y).setText(getConfigString("anglePIDAggKi")).setWidth(40).setAutoClear(false);
    x = x - 100;
    y = y+40;
    cp5.addTextfield("angle-PID ConKd").setPosition(x, y).setText(getConfigString("anglePIDConKd")).setWidth(40).setAutoClear(false);
    x = x + 100;
    cp5.addTextfield("angle-PID AggKd").setPosition(x, y).setText(getConfigString("anglePIDAggKd")).setWidth(40).setAutoClear(false);

    // angle general      
    cp5.addTextfield("angle-PID LowerLimit").setPosition(x=x-100, y=y+60).setText(getConfigString("anglePIDLowerLimit")).setWidth(40).setAutoClear(false);
    cp5.addTextfield("calibrated Zero Angle").setPosition(x, y=y+40).setText(getConfigString("calibratedZeroAngle")).setWidth(40).setAutoClear(false);
    cp5.addTextfield("angle-PID Sampling").setPosition(x, y=y+40).setText(getConfigString("anglePIDSampling")).setWidth(40).setAutoClear(false);
    cp5.addTextfield("angle Sensor Sampling").setPosition(x, y=y+40).setText(getConfigString("angleSensorSampling")).setWidth(40).setAutoClear(false);
    cp5.addTextfield("angle Kalman FilterR").setPosition(x, y=y+40).setText(getConfigString("angleKalmanFilterR")).setWidth(40).setAutoClear(false);

    // Debug
    cp5.addTextlabel("Debug").setText("Debug").setPosition(x=x+200, y=5).setFont(createFont("Georgia", 12));
    cp5.addToggle("debug Level").setPosition(x, y=y+40).setValue(PApplet.parseInt(getConfigString("debugLevel"))).setMode(ControlP5.SWITCH);
    cp5.addTextfield("debug Sample Rate").setPosition(x, y=y+40).setText(getConfigString("debugSampleRate")).setWidth(40).setAutoClear(false);
    cp5.addToggle("speed-PID OutputDebug").setPosition(x, y=y+40).setValue(PApplet.parseInt(getConfigString("speedPIDOutputDebug"))).setMode(ControlP5.SWITCH);
    cp5.addToggle("speed-PID InputDebug").setPosition(x, y=y+40).setValue(PApplet.parseInt(getConfigString("speedPIDInputDebug"))).setMode(ControlP5.SWITCH);
    cp5.addToggle("speed Kalman FilterDebug").setPosition(x, y=y+40).setValue(PApplet.parseInt(getConfigString("speedKalmanFilterDebug"))).setMode(ControlP5.SWITCH);
    cp5.addToggle("angle-PID SetpointDebug").setPosition(x, y=y+40).setValue(PApplet.parseInt(getConfigString("anglePIDSetpointDebug"))).setMode(ControlP5.SWITCH);
    cp5.addToggle("angle-PID InputDebug").setPosition(x, y=y+40).setValue(PApplet.parseInt(getConfigString("anglePIDInputDebug"))).setMode(ControlP5.SWITCH);
    cp5.addToggle("angle-PID OutputDebug").setPosition(x, y=y+40).setValue(PApplet.parseInt(getConfigString("anglePIDOutputDebug"))).setMode(ControlP5.SWITCH);
    cp5.addToggle("speed RawDebug").setPosition(x, y=y+40).setValue(PApplet.parseInt(getConfigString("speedRawDebug"))).setMode(ControlP5.SWITCH);
    cp5.addToggle("angle RawDebug").setPosition(x, y=y+40).setValue(PApplet.parseInt(getConfigString("angleRawDebug"))).setMode(ControlP5.SWITCH);

    PImage[] imgs = {
      loadImage(topSketchPath+"/images/button_a.png"), loadImage(topSketchPath+"/images/button_b.png"), loadImage(topSketchPath+"/images/button_c.png")
    };
    
    x = 200;
    cp5.addButton("moveForwards").setValue(1).setPosition(x, y=y+60).setImages(imgs).updateSize();
    cp5.addButton("moveBackwards").setValue(1).setPosition(x, y=y+60).setImages(imgs).updateSize();
    cp5.addButton("turnLeft").setValue(1).setPosition(x=x-60, y).setImages(imgs).updateSize();
    cp5.addButton("turnRight").setValue(1).setPosition(x=x+120, y).setImages(imgs).updateSize();
    
    cp5.addButton("start").setValue(1).setPosition(x=x-250, y=y-60);
    cp5.addButton("stop1").setValue(1).setPosition(x, y=y+40); // Do not run when setting  "stop"
    cp5.addButton("calibrate").setValue(1).setPosition(x, y=y+40);
  }



  public void controlEvent(ControlEvent theEvent) {
    print(theEvent);
    if (theEvent.isAssignableFrom(Textfield.class) || theEvent.isAssignableFrom(Toggle.class) || theEvent.isAssignableFrom(Button.class)) {
      String parameter = theEvent.getName();
      String value = "";
      if (theEvent.isAssignableFrom(Textfield.class))
        value = theEvent.getStringValue();
      else if (theEvent.isAssignableFrom(Toggle.class) || theEvent.isAssignableFrom(Button.class))
        value = theEvent.getValue()+"";

      robotConfigJSON.setString(parameter, value);
      saveJSONObject(robotConfigJSON, topSketchPath+"/robot_config.json");
      if (!mockupSerial) {
        serialPort.write("set "+parameter+" "+value+";");
        serialPort.clear();
      }
      print("set "+parameter+" "+value+";\n");
      /*for (int i=0; i<inBuffer.length; i++) {
       inBuffer[i] = 0;  
       }*/
    }
  }

  public void draw() {
    background(abc);
  }

  private ControlFrame() {
  }

  public ControlFrame(PApplet theParent, int theWidth, int theHeight, String _name) {
    parent = theParent;
    w = theWidth;
    h = theHeight;
    PApplet.runSketch(new String[]{this.getClass().getName()}, this);
  }


  public ControlP5 control() {
    return cp5;
  }


  ControlP5 cp5;

  PApplet parent;
}
public String getConfigString(String id) {
  String r = "";
  try {
    r = robotConfigJSON.getString(id);
  } 
  catch (Exception e) {
    r = "";
  }
  return r;
}
  
/*   =================================================================================       
     The Graph class contains functions and variables that have been created to draw 
     graphs. Here is a quick list of functions within the graph class:
          
       Graph(int x, int y, int w, int h,color k)
       DrawAxis()
       Bar([])
       smoothLine([][])
       DotGraph([][])
       LineGraph([][]) 
     
     =================================================================================*/   

    
    class Graph 
    {
      
      boolean Dot=true;            // Draw dots at each data point if true
      boolean RightAxis;            // Draw the next graph using the right axis if true
      boolean ErrorFlag=false;      // If the time array isn't in ascending order, make true  
      boolean ShowMouseLines=true;  // Draw lines and give values of the mouse position
    
      int     xDiv=5,yDiv=5;            // Number of sub divisions
      int     xPos,yPos;            // location of the top left corner of the graph  
      int     Width,Height;         // Width and height of the graph
    

      int   GraphColor;
      int   BackgroundColor=color(255);  
      int   StrokeColor=color(180);     
      
      String  Title="Title";          // Default titles
      String  xLabel="x - Label";
      String  yLabel="y - Label";

      float   yMax=1024, yMin=0;      // Default axis dimensions
      float   xMax=10, xMin=0;
      float   yMaxRight=1024,yMinRight=0;
  
      PFont   Font;                   // Selected font used for text 
      
  //    int Peakcounter=0,nPeakcounter=0;
     
      Graph(int x, int y, int w, int h,int k) {  // The main declaration function
        xPos = x;
        yPos = y;
        Width = w;
        Height = h;
        GraphColor = k;
        
      }
    
     
       public void DrawAxis(){
       
   /*  =========================================================================================
        Main axes Lines, Graph Labels, Graph Background
       ==========================================================================================  */
    
        fill(BackgroundColor); color(0);stroke(StrokeColor);strokeWeight(1);
        int t=60;
        
        rect(xPos-t*1.6f,yPos-t,Width+t*2.5f,Height+t*2);            // outline
        textAlign(CENTER);textSize(18);
        float c=textWidth(Title);
        fill(BackgroundColor); color(0);stroke(0);strokeWeight(1);
        rect(xPos+Width/2-c/2,yPos-35,c,0);                         // Heading Rectangle  
        
        fill(0);
        text(Title,xPos+Width/2,yPos-37);                            // Heading Title
        textAlign(CENTER);textSize(14);
        text(xLabel,xPos+Width/2,yPos+Height+t/1.5f);                     // x-axis Label 
        
        rotate(-PI/2);                                               // rotate -90 degrees
        text(yLabel,-yPos-Height/2,xPos-t*1.6f+20);                   // y-axis Label  
        rotate(PI/2);                                                // rotate back
        
        textSize(10); noFill(); stroke(0); smooth();strokeWeight(1);
          //Edges
          line(xPos-3,yPos+Height,xPos-3,yPos);                        // y-axis line 
          line(xPos-3,yPos+Height,xPos+Width+5,yPos+Height);           // x-axis line 
          
           stroke(200);
          if(yMin<0){
                    line(xPos-7,                                       // zero line 
                         yPos+Height-(abs(yMin)/(yMax-yMin))*Height,   // 
                         xPos+Width,
                         yPos+Height-(abs(yMin)/(yMax-yMin))*Height
                         );
          
                    
          }
          
          if(RightAxis){                                       // Right-axis line   
              stroke(0);
              line(xPos+Width+3,yPos+Height,xPos+Width+3,yPos);
            }
            
           /*  =========================================================================================
                Sub-devisions for both axes, left and right
               ==========================================================================================  */
            
            stroke(0);
            
           for(int x=0; x<=xDiv; x++){
       
            /*  =========================================================================================
                  x-axis
                ==========================================================================================  */
             
            line(PApplet.parseFloat(x)/xDiv*Width+xPos-3,yPos+Height,       //  x-axis Sub devisions    
                 PApplet.parseFloat(x)/xDiv*Width+xPos-3,yPos+Height+5);     
                 
            textSize(10);                                      // x-axis Labels
            String xAxis=str(xMin+PApplet.parseFloat(x)/xDiv*(xMax-xMin));  // the only way to get a specific number of decimals 
            String[] xAxisMS=split(xAxis,'.');                 // is to split the float into strings 
            text(xAxisMS[0]+"."+xAxisMS[1].charAt(0),          // ...
                 PApplet.parseFloat(x)/xDiv*Width+xPos-3,yPos+Height+15);   // x-axis Labels
          }
          
          
           /*  =========================================================================================
                 left y-axis
               ==========================================================================================  */
          
          for(int y=0; y<=yDiv; y++){
            line(xPos-3,PApplet.parseFloat(y)/yDiv*Height+yPos,                // ...
                  xPos-7,PApplet.parseFloat(y)/yDiv*Height+yPos);              // y-axis lines 
            
            textAlign(RIGHT);fill(20);
            
            String yAxis=str(yMin+PApplet.parseFloat(y)/yDiv*(yMax-yMin));     // Make y Label a string
            String[] yAxisMS=split(yAxis,'.');                    // Split string
           
            text(yAxisMS[0]+"."+yAxisMS[1].charAt(0),             // ... 
                 xPos-15,PApplet.parseFloat(yDiv-y)/yDiv*Height+yPos+3);       // y-axis Labels 
                        
                        
            /*  =========================================================================================
                 right y-axis
                ==========================================================================================  */
            
            if(RightAxis){
             
              color(GraphColor); stroke(GraphColor);fill(20);
            
              line(xPos+Width+3,PApplet.parseFloat(y)/yDiv*Height+yPos,             // ...
                   xPos+Width+7,PApplet.parseFloat(y)/yDiv*Height+yPos);            // Right Y axis sub devisions
                   
              textAlign(LEFT); 
            
              String yAxisRight=str(yMinRight+PApplet.parseFloat(y)/                // ...
                                yDiv*(yMaxRight-yMinRight));           // convert axis values into string
              String[] yAxisRightMS=split(yAxisRight,'.');             // 
           
               text(yAxisRightMS[0]+"."+yAxisRightMS[1].charAt(0),     // Right Y axis text
                    xPos+Width+15,PApplet.parseFloat(yDiv-y)/yDiv*Height+yPos+3);   // it's x,y location
            
              noFill();
            }stroke(0);
            
          
          }
          
 
      }
      
      
   /*  =========================================================================================
       Bar graph
       ==========================================================================================  */   
      
      public void Bar(float[] a ,int from, int to) {
        
         
          stroke(GraphColor);
          fill(GraphColor);
          
          if(from<0){                                      // If the From or To value is out of bounds 
           for (int x=0; x<a.length; x++){                 // of the array, adjust them 
               rect(PApplet.parseInt(xPos+x*PApplet.parseFloat(Width)/(a.length)),
                    yPos+Height-2,
                    Width/a.length-2,
                    -a[x]/(yMax-yMin)*Height);
                 }
          }
          
          else {
          for (int x=from; x<to; x++){
            
            rect(PApplet.parseInt(xPos+(x-from)*PApplet.parseFloat(Width)/(to-from)),
                     yPos+Height-2,
                     Width/(to-from)-2,
                     -a[x]/(yMax-yMin)*Height);
                     
    
          }
          }
          
      }
  public void Bar(float[] a ) {
  
              stroke(GraphColor);
          fill(GraphColor);
    
  for (int x=0; x<a.length; x++){                 // of the array, adjust them 
               rect(PApplet.parseInt(xPos+x*PApplet.parseFloat(Width)/(a.length)),
                    yPos+Height-2,
                    Width/a.length-2,
                    -a[x]/(yMax-yMin)*Height);
                 }
          }
  
  
   /*  =========================================================================================
       Dot graph
       ==========================================================================================  */   
       
        public void DotGraph(float[] x ,float[] y) {
          
         for (int i=0; i<x.length; i++){
                    strokeWeight(2);stroke(GraphColor);noFill();smooth();
           ellipse(
                   xPos+(x[i]-x[0])/(x[x.length-1]-x[0])*Width,
                   yPos+Height-(y[i]/(yMax-yMin)*Height)+(yMin)/(yMax-yMin)*Height,
                   2,2
                   );
         }
                             
      }
      
   /*  =========================================================================================
       XY Dot graph
       ==========================================================================================  */   
       
        public void DotXY(float[] x ,float[] y) {
          
         for (int i=0; i<x.length; i++){
                    strokeWeight(2);stroke(GraphColor);noFill();smooth();
           ellipse(
                   xPos-(xMin/(xMax-xMin)*Width)+(x[i])/(xMax-xMin)*Width,
                   yPos+Height-(y[i]/(yMax-yMin)*Height)+(yMin)/(yMax-yMin)*Height,
                   2,2
                   );
         }
                             
      }
      
   /*  =========================================================================================
       Streight line graph 
       ==========================================================================================  */
       
      public void LineGraph(float[] x ,float[] y) {
          
         for (int i=0; i<(x.length-1); i++){
                    strokeWeight(2);stroke(GraphColor);noFill();smooth();
           line(xPos+(x[i]-x[0])/(x[x.length-1]-x[0])*Width,
                                            yPos+Height-(y[i]/(yMax-yMin)*Height)+(yMin)/(yMax-yMin)*Height,
                                            xPos+(x[i+1]-x[0])/(x[x.length-1]-x[0])*Width,
                                            yPos+Height-(y[i+1]/(yMax-yMin)*Height)+(yMin)/(yMax-yMin)*Height);
         }
                             
      }
      
      /*  =========================================================================================
             smoothLine
          ==========================================================================================  */
    
      public void smoothLine(float[] x ,float[] y) {
         
        float tempyMax=yMax, tempyMin=yMin;
        
        if(RightAxis){yMax=yMaxRight;yMin=yMinRight;} 
         
        int counter=0;
        int xlocation=0,ylocation=0;
         
//         if(!ErrorFlag |true ){    // sort out later!
          
          beginShape(); strokeWeight(2);stroke(GraphColor);noFill();smooth();
         
            for (int i=0; i<x.length; i++){
              
           /* ===========================================================================
               Check for errors-> Make sure time array doesn't decrease (go back in time) 
              ===========================================================================*/
              if(i<x.length-1){
                if(x[i]>x[i+1]){
                   
                  ErrorFlag=true;
                
                }
              }
         
         /* =================================================================================       
             First and last bits can't be part of the curve, no points before first bit, 
             none after last bit. So a streight line is drawn instead   
            ================================================================================= */ 

              if(i==0 || i==x.length-2)line(xPos+(x[i]-x[0])/(x[x.length-1]-x[0])*Width,
                                            yPos+Height-(y[i]/(yMax-yMin)*Height)+(yMin)/(yMax-yMin)*Height,
                                            xPos+(x[i+1]-x[0])/(x[x.length-1]-x[0])*Width,
                                            yPos+Height-(y[i+1]/(yMax-yMin)*Height)+(yMin)/(yMax-yMin)*Height);
                                            
          /* =================================================================================       
              For the rest of the array a curve (spline curve) can be created making the graph 
              smooth.     
             ================================================================================= */ 
                            
              curveVertex( xPos+(x[i]-x[0])/(x[x.length-1]-x[0])*Width,
                           yPos+Height-(y[i]/(yMax-yMin)*Height)+(yMin)/(yMax-yMin)*Height);
                           
           /* =================================================================================       
              If the Dot option is true, Place a dot at each data point.  
             ================================================================================= */    
           
             if(Dot)ellipse(
                             xPos+(x[i]-x[0])/(x[x.length-1]-x[0])*Width,
                             yPos+Height-(y[i]/(yMax-yMin)*Height)+(yMin)/(yMax-yMin)*Height,
                             2,2
                             );
                             
         /* =================================================================================       
             Highlights points closest to Mouse X position   
            =================================================================================*/ 
                          
              if( abs(mouseX-(xPos+(x[i]-x[0])/(x[x.length-1]-x[0])*Width))<5 ){
                
                 
                  float yLinePosition = yPos+Height-(y[i]/(yMax-yMin)*Height)+(yMin)/(yMax-yMin)*Height;
                  float xLinePosition = xPos+(x[i]-x[0])/(x[x.length-1]-x[0])*Width;
                  strokeWeight(1);stroke(240);
                 // line(xPos,yLinePosition,xPos+Width,yLinePosition);
                  strokeWeight(2);stroke(GraphColor);
                  
                  ellipse(xLinePosition,yLinePosition,4,4);
              }
              
     
              
            }  
       
          endShape(); 
          yMax=tempyMax; yMin=tempyMin;
                float xAxisTitleWidth=textWidth(str(map(xlocation,xPos,xPos+Width,x[0],x[x.length-1])));
          
           
       if((mouseX>xPos&mouseX<(xPos+Width))&(mouseY>yPos&mouseY<(yPos+Height))){   
        if(ShowMouseLines){
              // if(mouseX<xPos)xlocation=xPos;
            if(mouseX>xPos+Width)xlocation=xPos+Width;
            else xlocation=mouseX;
            stroke(200); strokeWeight(0.5f);fill(255);color(50);
            // Rectangle and x position
            line(xlocation,yPos,xlocation,yPos+Height);
            rect(xlocation-xAxisTitleWidth/2-10,yPos+Height-16,xAxisTitleWidth+20,12);
            
            textAlign(CENTER); fill(160);
            text(map(xlocation,xPos,xPos+Width,x[0],x[x.length-1]),xlocation,yPos+Height-6);
            
           // if(mouseY<yPos)ylocation=yPos;
             if(mouseY>yPos+Height)ylocation=yPos+Height;
            else ylocation=mouseY;
          
           // Rectangle and y position
            stroke(200); strokeWeight(0.5f);fill(255);color(50);
            
            line(xPos,ylocation,xPos+Width,ylocation);
             int yAxisTitleWidth=PApplet.parseInt(textWidth(str(map(ylocation,yPos,yPos+Height,y[0],y[y.length-1]))) );
            rect(xPos-15+3,ylocation-6, -60 ,12);
            
            textAlign(RIGHT); fill(GraphColor);//StrokeColor
          //    text(map(ylocation,yPos+Height,yPos,yMin,yMax),xPos+Width+3,yPos+Height+4);
            text(map(ylocation,yPos+Height,yPos,yMin,yMax),xPos -15,ylocation+4);
           if(RightAxis){ 
                          
                           stroke(200); strokeWeight(0.5f);fill(255);color(50);
                           
                           rect(xPos+Width+15-3,ylocation-6, 60 ,12);  
                            textAlign(LEFT); fill(160);
                           text(map(ylocation,yPos+Height,yPos,yMinRight,yMaxRight),xPos+Width+15,ylocation+4);
           }
            noStroke();noFill();
         }
       }
            
   
      }

       
          public void smoothLine(float[] x ,float[] y, float[] z, float[] a ) {
           GraphColor=color(188,53,53);
            smoothLine(x ,y);
           GraphColor=color(193-100,216-100,16);
           smoothLine(z ,a);
   
       }
       
       
       
    }
    
 
// If you want to debug the plotter without using a real serial port
// MOdified to mock a mmtk output
// SPEED POSITION LOADCELL FEEDBACK_COUNT STATE ESTOP STALL DIRECTION INPUT_VOLTAGE BT_FWD BT_BAK BT_TARE BT_START BT_AUX
// typedef enum {running, stopped, hold, jogFwd, jogBak, fastFwd, fastBak, noChange} MMTKState_t;



Random rand = new Random();

// These values are retained after function exits

float mockSpeed = 0.0f;
float mockPosition = 0;
float mockLoadCell = 0.0f;
int mockFeedBack = 0;
int mockState = 0;
boolean mockEstop = false;
boolean mockStall = false;
boolean mockDirection = false;
float mockInputVolts = 12.0f;
boolean mockBtBak = false;
boolean mockBtFwd = false;
boolean mockBtTare = false;
boolean mockBtStart = false;
boolean mockBtAux = false;

public String mockupSerialFunction() {
  mockPosition += 1;
  
  if (mockPosition > 1000) {
    mockPosition = 0;
  }
  
  mockLoadCell = rand.nextFloat() * 500;
  
  mockFeedBack += 1;
  
  mockSpeed = (mockLoadCell + mockPosition) / 3;
  
  mockInputVolts = 11.5f + rand.nextFloat();
  
  if (mockPosition % 25 == 0) {
    mockState = ThreadLocalRandom.current().nextInt(0, 6);
  }
  
  if (mockPosition % 10 == 0) {
    mockEstop = rand.nextFloat() > 0.3f;
    mockStall = rand.nextFloat() > 0.4f;
    mockDirection = rand.nextFloat() > 0.5f;
    mockBtBak = rand.nextFloat() > 0.7f;
    mockBtFwd = rand.nextFloat() > 0.3f;
    mockBtTare = rand.nextFloat() > 0.4f;
    mockBtStart = rand.nextFloat() > 0.5f;
    mockBtAux = rand.nextFloat() > 0.6f;
  }
  
  

  String r = "";
  for (int i = 0; i<14; i++) {
    switch (i) {
    case 0:
      r += mockSpeed+" ";
      break;
    case 1:
      r += mockPosition+" ";
      break;
    case 2:
      r += mockLoadCell+" ";
      break;
    case 3:
      r += mockFeedBack+" ";
      break;
    case 4:
      r += mockState+" ";
      break;
    case 5:
      if (mockEstop) {
        r += "1 ";
      } else {
        r += "0 ";
      }
      break;
    case 6:
      if (mockStall) {
        r += "1 ";
      } else {
        r += "0 ";
      }
      break;
    case 7:
      if (mockDirection) {
        r += "1 ";
      } else {
        r += "0 ";
      }
      break;
    case 8:
      r += mockInputVolts+" ";
      break;
    case 9:
      if (mockBtFwd) {
        r += "1 ";
      } else {
        r += "0 ";
      }
      break;
    case 10:
      if (mockBtBak) {
        r += "1 ";
      } else {
        r += "0 ";
      }
      break;
    case 11:
      if (mockBtTare) {
        r += "1 ";
      } else {
        r += "0 ";
      }
      break;
    case 12:
      if (mockBtStart) {
        r += "1 ";
      } else {
        r += "0 ";
      }
      break;
    case 13:
      if (mockBtAux) {
        r += "1 ";
      } else {
        r += "0 ";
      }
      break;
    }
    if (i < 14)
      r += '\r';
  }
  delay(10);
  return r;
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "MMTK_UI" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
